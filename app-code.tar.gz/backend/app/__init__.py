# HiBid Email MVP Backend Application

